# Zaitsev Holding Group - Cloudflare Deployment Guide

## 🎯 Quick Start

Your website is ready to deploy to Cloudflare Pages for the domain **zaitsev.co**

## 📋 Pre-Deployment Checklist

- [x] All HTML pages created (index, about, portfolio, contact)
- [x] CSS styling completed
- [x] JavaScript functionality implemented
- [x] Logo optimized and included
- [x] Responsive design tested
- [x] All links are relative paths

## 🚀 Deployment Methods

### Method 1: GitHub + Cloudflare Pages (Recommended)

This method provides automatic deployments whenever you push changes to GitHub.

#### Step 1: Push to GitHub

1. **Create a new repository on GitHub**
   - Go to https://github.com/new
   - Name it: `zaitsev-holding-website` (or your preferred name)
   - Make it private or public
   - Don't initialize with README (we already have files)

2. **Push your code to GitHub**
   ```bash
   cd zaitsev-website
   git init
   git add .
   git commit -m "Initial commit - Zaitsev Holding Group website"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/zaitsev-holding-website.git
   git push -u origin main
   ```

#### Step 2: Connect to Cloudflare Pages

1. **Login to Cloudflare**
   - Go to https://dash.cloudflare.com/
   - Login with your account

2. **Create a new Pages project**
   - Click on **Pages** in the left sidebar
   - Click **Create a project**
   - Select **Connect to Git**

3. **Authorize GitHub**
   - Click **Connect GitHub**
   - Authorize Cloudflare to access your repositories
   - Select your repository: `zaitsev-holding-website`

4. **Configure build settings**
   - **Project name**: `zaitsev-co` (this will be your subdomain)
   - **Production branch**: `main`
   - **Framework preset**: None
   - **Build command**: Leave empty
   - **Build output directory**: `/` (or leave empty)
   - Click **Save and Deploy**

5. **Wait for deployment**
   - Cloudflare will build and deploy your site
   - You'll get a URL like: `zaitsev-co.pages.dev`
   - Test this URL to ensure everything works

#### Step 3: Configure Custom Domain

1. **Add custom domain**
   - In your Pages project, go to **Custom domains**
   - Click **Set up a custom domain**
   - Enter: `zaitsev.co`
   - Click **Continue**

2. **Configure DNS**
   
   If your domain is already on Cloudflare:
   - Cloudflare will automatically add the CNAME record
   - Just click **Activate domain**
   
   If your domain is NOT on Cloudflare:
   - You'll need to add a CNAME record at your domain registrar
   - **Type**: CNAME
   - **Name**: `@` or `zaitsev.co`
   - **Value**: `zaitsev-co.pages.dev` (your Pages URL)
   - **TTL**: Auto or 3600

3. **Add www subdomain** (optional but recommended)
   - Click **Set up a custom domain** again
   - Enter: `www.zaitsev.co`
   - Follow the same DNS configuration steps

4. **Wait for DNS propagation**
   - DNS changes can take 5 minutes to 48 hours
   - Usually completes within 15-30 minutes
   - Check status in Cloudflare dashboard

### Method 2: Direct Upload (Fastest)

Use this method if you don't want to use GitHub or need to deploy immediately.

1. **Prepare files**
   - Ensure all files are in the `zaitsev-website` folder
   - Create a ZIP file of the entire folder (optional)

2. **Upload to Cloudflare Pages**
   - Go to https://dash.cloudflare.com/
   - Click **Pages** → **Create a project**
   - Select **Upload assets**
   - Drag and drop the `zaitsev-website` folder (or ZIP file)
   - Click **Deploy site**

3. **Configure custom domain**
   - Follow Step 3 from Method 1 above

### Method 3: Wrangler CLI (For Developers)

1. **Install Wrangler**
   ```bash
   npm install -g wrangler
   ```

2. **Login to Cloudflare**
   ```bash
   wrangler login
   ```

3. **Deploy**
   ```bash
   cd zaitsev-website
   wrangler pages publish . --project-name=zaitsev-co
   ```

4. **Configure custom domain**
   - Follow Step 3 from Method 1 above

## 🔧 Post-Deployment Configuration

### SSL/TLS Settings

1. Go to **SSL/TLS** in Cloudflare dashboard
2. Set encryption mode to **Full** or **Full (strict)**
3. Enable **Always Use HTTPS**
4. Enable **Automatic HTTPS Rewrites**

### Performance Settings

1. Go to **Speed** → **Optimization**
2. Enable **Auto Minify** for HTML, CSS, and JavaScript
3. Enable **Brotli** compression
4. Enable **Early Hints**

### Security Settings

1. Go to **Security** → **Settings**
2. Set Security Level to **Medium** or **High**
3. Enable **Bot Fight Mode**
4. Consider enabling **WAF** (Web Application Firewall)

### Caching

1. Go to **Caching** → **Configuration**
2. Set Browser Cache TTL to **4 hours** or **1 day**
3. Enable **Always Online**

## 📧 Contact Form Setup

The contact form currently shows an alert. To make it functional:

### Option 1: Cloudflare Workers (Recommended)

1. Create a Worker to handle form submissions
2. Use the Cloudflare Email Routing or integrate with SendGrid/Mailgun
3. Update the form action in `contact.html` and `js/main.js`

### Option 2: Third-Party Form Service

**Formspree** (Easiest):
1. Go to https://formspree.io/
2. Create a free account
3. Create a new form
4. Update the form action in `contact.html`:
   ```html
   <form action="https://formspree.io/f/YOUR_FORM_ID" method="POST">
   ```

**Basin**:
1. Go to https://usebasin.com/
2. Create account and form
3. Update form action with Basin endpoint

## 🔍 Testing Checklist

After deployment, test the following:

- [ ] Homepage loads correctly
- [ ] All navigation links work
- [ ] About page displays properly
- [ ] Portfolio page shows all companies
- [ ] Contact page loads and form displays
- [ ] Mobile responsiveness (test on phone)
- [ ] Logo displays correctly
- [ ] All images load
- [ ] Footer links work
- [ ] HTTPS is working (padlock in browser)
- [ ] www redirect works (if configured)

## 🐛 Troubleshooting

### Site not loading
- Check DNS settings in Cloudflare
- Verify CNAME record is correct
- Wait for DNS propagation (up to 48 hours)
- Clear browser cache

### Images not displaying
- Check file paths are relative (not absolute)
- Verify images are in the `images` folder
- Check file names match exactly (case-sensitive)

### CSS not applying
- Check `styles.css` path in HTML files
- Verify CSS file uploaded correctly
- Clear browser cache and hard refresh (Ctrl+F5)

### Mobile menu not working
- Check `main.js` is loaded correctly
- Open browser console for JavaScript errors
- Verify Font Awesome icons are loading

### Contact form not working
- This is expected - form needs backend setup
- Follow "Contact Form Setup" section above
- Test with a form service like Formspree

## 📊 Analytics Setup (Optional)

### Google Analytics 4

1. Create GA4 property at https://analytics.google.com/
2. Get your Measurement ID (G-XXXXXXXXXX)
3. Add this code before `</head>` in all HTML files:

```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>
```

### Cloudflare Web Analytics (Free)

1. Go to **Analytics** → **Web Analytics** in Cloudflare
2. Click **Add a site**
3. Copy the JavaScript snippet
4. Add before `</body>` in all HTML files

## 🔄 Updating Your Website

### If using GitHub (Method 1):
```bash
# Make your changes to the files
git add .
git commit -m "Description of changes"
git push
```
Cloudflare will automatically deploy the changes!

### If using Direct Upload (Method 2):
1. Make changes to your local files
2. Go to Cloudflare Pages dashboard
3. Click on your project
4. Click **Create deployment**
5. Upload the updated files

## 📞 Support Resources

- **Cloudflare Docs**: https://developers.cloudflare.com/pages/
- **Cloudflare Community**: https://community.cloudflare.com/
- **DNS Checker**: https://dnschecker.org/ (check DNS propagation)
- **SSL Checker**: https://www.sslshopper.com/ssl-checker.html

## ✅ Success Indicators

Your deployment is successful when:
- ✅ Site loads at zaitsev.co
- ✅ HTTPS padlock shows in browser
- ✅ All pages are accessible
- ✅ Mobile version works correctly
- ✅ Images and logo display properly
- ✅ Navigation works smoothly

## 🎉 You're Done!

Your Zaitsev Holding Group website is now live on Cloudflare Pages!

**Next Steps:**
1. Test thoroughly on different devices
2. Set up contact form backend
3. Add Google Analytics (optional)
4. Share with stakeholders
5. Monitor performance in Cloudflare dashboard

---

**Need Help?** Contact Cloudflare support or refer to their comprehensive documentation.