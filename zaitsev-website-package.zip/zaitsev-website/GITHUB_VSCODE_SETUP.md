# GitHub + VS Code Setup Guide for Zaitsev Holding Group Website

This guide will help you set up your website with GitHub and VS Code so you can easily edit and update it.

## 🎯 What You'll Achieve

- Edit your website locally in VS Code
- Track all changes with Git
- Push updates to GitHub
- Automatic deployment to Cloudflare when you push changes
- Professional development workflow

## 📋 Prerequisites

You'll need to install:
1. **VS Code** - https://code.visualstudio.com/
2. **Git** - https://git-scm.com/downloads
3. **GitHub Account** - https://github.com/signup (free)

## 🚀 Step-by-Step Setup

### Step 1: Install Required Software

#### Install VS Code
1. Go to https://code.visualstudio.com/
2. Download for your operating system (Windows/Mac/Linux)
3. Run the installer
4. Open VS Code after installation

#### Install Git
1. Go to https://git-scm.com/downloads
2. Download for your operating system
3. Run the installer (use default settings)
4. Verify installation by opening Terminal/Command Prompt and typing:
   ```bash
   git --version
   ```
   You should see something like: `git version 2.x.x`

#### Create GitHub Account
1. Go to https://github.com/signup
2. Create a free account
3. Verify your email address

### Step 2: Set Up Git Configuration

Open Terminal (Mac/Linux) or Command Prompt (Windows) and run:

```bash
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"
```

Replace with your actual name and email (use the same email as your GitHub account).

### Step 3: Extract and Open Project in VS Code

1. **Extract the ZIP file**
   - Unzip `zaitsev-website-package.zip` to a location like:
     - Windows: `C:\Users\YourName\Documents\zaitsev-website`
     - Mac: `/Users/YourName/Documents/zaitsev-website`

2. **Open in VS Code**
   - Open VS Code
   - Click **File** → **Open Folder**
   - Navigate to and select the `zaitsev-website` folder
   - Click **Select Folder** (Windows) or **Open** (Mac)

### Step 4: Initialize Git Repository

In VS Code:

1. **Open Terminal in VS Code**
   - Click **Terminal** → **New Terminal** (or press `` Ctrl+` ``)

2. **Initialize Git**
   ```bash
   git init
   ```

3. **Add all files**
   ```bash
   git add .
   ```

4. **Create first commit**
   ```bash
   git commit -m "Initial commit - Zaitsev Holding Group website"
   ```

### Step 5: Create GitHub Repository

1. **Go to GitHub**
   - Visit https://github.com/new
   - Or click the **+** icon in top right → **New repository**

2. **Configure Repository**
   - **Repository name**: `zaitsev-holding-website` (or your preferred name)
   - **Description**: "Official website for Zaitsev Holding Group, LLC"
   - **Visibility**: 
     - Choose **Private** (recommended for business sites)
     - Or **Public** if you want it visible
   - **DO NOT** check "Initialize with README" (we already have files)
   - Click **Create repository**

3. **Copy Repository URL**
   - You'll see a URL like: `https://github.com/yourusername/zaitsev-holding-website.git`
   - Copy this URL

### Step 6: Connect Local Project to GitHub

In VS Code Terminal, run these commands (replace with your actual GitHub URL):

```bash
# Add GitHub as remote
git remote add origin https://github.com/yourusername/zaitsev-holding-website.git

# Rename branch to main (if needed)
git branch -M main

# Push to GitHub
git push -u origin main
```

**If prompted for credentials:**
- Username: Your GitHub username
- Password: Use a **Personal Access Token** (not your password)

#### Creating a Personal Access Token (if needed):
1. Go to https://github.com/settings/tokens
2. Click **Generate new token** → **Generate new token (classic)**
3. Give it a name: "Zaitsev Website"
4. Select scopes: Check **repo** (full control)
5. Click **Generate token**
6. **COPY THE TOKEN** (you won't see it again!)
7. Use this token as your password when pushing

### Step 7: Connect GitHub to Cloudflare Pages

1. **Go to Cloudflare Dashboard**
   - Visit https://dash.cloudflare.com/
   - Login to your account

2. **Create Pages Project**
   - Click **Pages** in the left sidebar
   - Click **Create a project**
   - Select **Connect to Git**

3. **Authorize GitHub**
   - Click **Connect GitHub**
   - Authorize Cloudflare to access your repositories
   - Select your repository: `zaitsev-holding-website`

4. **Configure Build Settings**
   - **Project name**: `zaitsev-co`
   - **Production branch**: `main`
   - **Framework preset**: None
   - **Build command**: Leave empty
   - **Build output directory**: `/` (or leave empty)
   - Click **Save and Deploy**

5. **Wait for First Deployment**
   - Cloudflare will deploy your site
   - You'll get a URL like: `zaitsev-co.pages.dev`

6. **Add Custom Domain**
   - Go to **Custom domains** tab
   - Click **Set up a custom domain**
   - Enter: `zaitsev.co`
   - Follow DNS configuration instructions

## 🎨 Daily Workflow: Making Changes

### Making Edits in VS Code

1. **Open VS Code** with your project folder

2. **Edit Files**
   - Click on any file in the left sidebar to edit
   - Make your changes
   - Save with `Ctrl+S` (Windows) or `Cmd+S` (Mac)

3. **Preview Changes Locally** (Optional)
   - Open Terminal in VS Code
   - Run: `python -m http.server 8000`
   - Open browser to: `http://localhost:8000`
   - Press `Ctrl+C` to stop the server

### Pushing Changes to GitHub (and Auto-Deploy)

After making changes:

1. **Stage Changes**
   - In VS Code, click the **Source Control** icon (left sidebar)
   - Or press `Ctrl+Shift+G` (Windows) or `Cmd+Shift+G` (Mac)
   - You'll see all changed files

2. **Commit Changes**
   - Type a commit message describing your changes:
     - "Updated contact information"
     - "Added new portfolio company"
     - "Fixed typo on about page"
   - Click the **✓ Commit** button

3. **Push to GitHub**
   - Click the **...** menu → **Push**
   - Or use Terminal: `git push`

4. **Automatic Deployment**
   - Cloudflare automatically detects the push
   - Builds and deploys your changes
   - Usually takes 1-2 minutes
   - Your site at zaitsev.co updates automatically!

## 🔄 Complete Example Workflow

Let's say you want to update the contact email:

```bash
# 1. Open VS Code and edit contact.html
# 2. Change the email address
# 3. Save the file (Ctrl+S or Cmd+S)

# 4. In VS Code Terminal or Source Control:
git add contact.html
git commit -m "Updated contact email address"
git push

# 5. Wait 1-2 minutes
# 6. Visit zaitsev.co - your changes are live!
```

## 🛠️ Useful VS Code Extensions

Install these extensions to make editing easier:

1. **Live Server** (by Ritwick Dey)
   - Preview HTML changes in real-time
   - Right-click HTML file → "Open with Live Server"

2. **Prettier** (by Prettier)
   - Auto-format your code
   - Makes code look clean and consistent

3. **HTML CSS Support** (by ecmel)
   - Better HTML and CSS editing
   - Auto-completion for classes

4. **GitLens** (by GitKraken)
   - Enhanced Git features
   - See who changed what and when

### Installing Extensions:
1. Click Extensions icon in VS Code (left sidebar)
2. Search for extension name
3. Click **Install**

## 📝 Common Git Commands

### Checking Status
```bash
git status                 # See what files changed
```

### Making Changes
```bash
git add .                  # Stage all changes
git add filename.html      # Stage specific file
git commit -m "message"    # Commit with message
git push                   # Push to GitHub
```

### Viewing History
```bash
git log                    # See commit history
git log --oneline          # Compact history view
```

### Undoing Changes
```bash
git checkout filename.html # Discard changes to file
git reset HEAD~1           # Undo last commit (keep changes)
```

### Pulling Latest Changes
```bash
git pull                   # Get latest from GitHub
```

## 🔐 Security Best Practices

### .gitignore File
Already included! This prevents sensitive files from being uploaded to GitHub.

### Environment Variables
If you add API keys or secrets later:
1. Create a `.env` file (already in .gitignore)
2. Store secrets there
3. Never commit .env to GitHub

### Private Repository
Keep your repository private if it contains:
- Business-sensitive information
- Unpublished features
- Internal documentation

## 🐛 Troubleshooting

### "Permission denied" when pushing
- Use a Personal Access Token instead of password
- See Step 6 for creating a token

### "Repository not found"
- Check your remote URL: `git remote -v`
- Update if wrong: `git remote set-url origin NEW_URL`

### Changes not showing on website
- Check Cloudflare Pages deployment status
- Wait 2-3 minutes for deployment
- Clear browser cache (Ctrl+Shift+R)

### Merge conflicts
```bash
git pull                   # Get latest changes
# Fix conflicts in VS Code (it highlights them)
git add .
git commit -m "Resolved conflicts"
git push
```

## 📱 Mobile Editing (Optional)

You can even edit on mobile/tablet:

1. **GitHub Mobile App**
   - Download from App Store/Play Store
   - Edit files directly on GitHub
   - Changes auto-deploy to Cloudflare

2. **Working Copy** (iOS)
   - Full Git client for iPad/iPhone
   - Clone your repository
   - Edit and push changes

## 🎯 Quick Reference Card

### Daily Workflow
```bash
# 1. Make changes in VS Code
# 2. Save files
# 3. Commit and push:
git add .
git commit -m "Description of changes"
git push
# 4. Wait 1-2 minutes for auto-deployment
```

### File Structure
```
zaitsev-website/
├── index.html          ← Edit homepage
├── about.html          ← Edit about page
├── portfolio.html      ← Edit portfolio
├── contact.html        ← Edit contact page
├── css/
│   └── styles.css      ← Edit styling
└── js/
    └── main.js         ← Edit functionality
```

## ✅ Setup Checklist

- [ ] VS Code installed
- [ ] Git installed and configured
- [ ] GitHub account created
- [ ] Project opened in VS Code
- [ ] Git repository initialized
- [ ] GitHub repository created
- [ ] Local project connected to GitHub
- [ ] First push to GitHub successful
- [ ] Cloudflare Pages connected to GitHub
- [ ] Custom domain (zaitsev.co) configured
- [ ] Made a test edit and pushed successfully
- [ ] Verified auto-deployment works

## 🎉 You're All Set!

Now you can:
- ✅ Edit your website in VS Code
- ✅ Track all changes with Git
- ✅ Push updates to GitHub
- ✅ Automatically deploy to zaitsev.co
- ✅ Collaborate with team members (if needed)

## 📚 Learning Resources

### Git Basics
- GitHub's Git Guide: https://guides.github.com/introduction/git-handbook/
- Interactive Git Tutorial: https://learngitbranching.js.org/

### VS Code
- VS Code Tips: https://code.visualstudio.com/docs/getstarted/tips-and-tricks
- VS Code for Web Dev: https://code.visualstudio.com/docs/languages/html

### Cloudflare Pages
- Cloudflare Pages Docs: https://developers.cloudflare.com/pages/

## 💡 Pro Tips

1. **Commit Often**: Make small, frequent commits with clear messages
2. **Test Locally**: Preview changes before pushing
3. **Descriptive Messages**: Write clear commit messages
4. **Backup**: GitHub is your backup - push regularly
5. **Branch for Big Changes**: Use branches for major updates

---

**Need Help?** 
- GitHub Support: https://support.github.com/
- VS Code Docs: https://code.visualstudio.com/docs
- Cloudflare Community: https://community.cloudflare.com/

**Happy Coding! 🚀**